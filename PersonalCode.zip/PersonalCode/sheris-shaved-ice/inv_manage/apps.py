from django.apps import AppConfig


class InvManageConfig(AppConfig):
    name = 'inv_manage'
