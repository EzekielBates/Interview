thing = $(function(){
    $("#data-table").colResizable({
        liveDrag: true,
        minWidth: 30
    });
});
